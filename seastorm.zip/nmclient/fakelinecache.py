# this is a fake class that makes traceback work.   I need to avoid the real
# linecache because it uses open

def checkcache(filename):
  pass

def getline(a,b,c):
  pass
